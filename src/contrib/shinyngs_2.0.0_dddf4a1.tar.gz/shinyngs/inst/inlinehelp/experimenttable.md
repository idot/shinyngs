This page shows the experimental information supplied along with primary data (e.g. sequencing reads) for analysis. This information may have been used to apply a batch correction and to define groups of samples to compare against one another. Factors from this table can be used to color plots in other parts of the application.

