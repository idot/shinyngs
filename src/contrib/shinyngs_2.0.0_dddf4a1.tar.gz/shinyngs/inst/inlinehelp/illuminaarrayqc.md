
#### Introduction

This page simply plots the mean of control probes in each group for each sample in an Illumina microarray experiment. 

Things to check are detailed at the left, and are:

* cy3_high > cy3_med > cy3_low
* low stringency =~ 0
* high stringency <= cy3 high
* housekeeping = high
* biotin = high
* negative =~ 0
