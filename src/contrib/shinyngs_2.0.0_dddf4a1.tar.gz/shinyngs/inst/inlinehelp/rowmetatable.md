This page shows the metadata associated with each row of the matrices in the selected experiment, for example with the genes or transcripts of a gene expression experiment. The content of this table is dependent on what was added to the dataset during analysis.

